import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://dbexerljgcllahirbgrh.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRiZXhlcmxqZ2NsbGFoaXJiZ3JoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQyOTIzNzksImV4cCI6MjA1OTg2ODM3OX0.m1AmKgJmV-L1V26RedeaFRCo2C3DwFlW-bbzUjYou5w';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
